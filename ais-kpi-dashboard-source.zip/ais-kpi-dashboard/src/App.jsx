import { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import LoginPage from './components/Auth/LoginPage';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import DashboardPage from './pages/DashboardPage';

const NAV_TITLES = {
  dashboard: 'EC KPI Dashboard — Overview',
  kpi1: 'KPI 1 — Online Lead Conversion to EC Visit',
  kpi2: 'KPI 2 — Architect Invitation Conversion',
  kpi3: 'KPI 3 — Customer Footfall Tracking',
  kpi4: 'KPI 4 — Showroom Upkeep & Maintenance',
  kpi5: 'KPI 5 — Data Management & MIS Hygiene',
  kpi6: 'KPI 6 — Presentation Skills & Product Knowledge',
  kpi7: 'KPI 7 — Architect Footfall Feedback',
  kpi8: 'KPI 8 — Showroom Expense Management',
  kpi9: 'KPI 9 — EC Audit Score',
  kpi10: 'KPI 10 — Salesperson Performance Plan',
  kpi11: 'KPI 11 — Customer Footfall Feedback',
  analytics: 'Analytics & AI-Powered Insights',
};

const AppShell = () => {
  const { hasAccess, loading } = useAuth();
  const [activePage, setActivePage] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0A1628' }}>
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto mb-4 animate-pulse"
            style={{ background: 'linear-gradient(135deg, #00B4D8, #0096C7)', fontFamily: 'Rajdhani, sans-serif', color: '#fff' }}>
            AIS
          </div>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!hasAccess) return <LoginPage />;

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#0A1628' }}>
      <Sidebar active={activePage} setActive={setActivePage} collapsed={sidebarCollapsed} setCollapsed={setSidebarCollapsed} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header title={NAV_TITLES[activePage] || 'Dashboard'} />
        <main className="flex-1 overflow-y-auto px-5 py-5" style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(0,180,216,0.3) transparent' }}>
          <DashboardPage activePage={activePage} />
          <div className="h-8" />
        </main>
      </div>
    </div>
  );
};

const App = () => (
  <AuthProvider>
    <DataProvider>
      <AppShell />
      <Toaster position="bottom-right" toastOptions={{ style: { background: '#0d1f3c', color: '#fff', border: '1px solid rgba(0,180,216,0.3)', borderRadius: 12, fontSize: 13 }, success: { iconTheme: { primary: '#4ADE80', secondary: '#0d1f3c' } }, error: { iconTheme: { primary: '#F87171', secondary: '#0d1f3c' } } }} />
    </DataProvider>
  </AuthProvider>
);

export default App;
